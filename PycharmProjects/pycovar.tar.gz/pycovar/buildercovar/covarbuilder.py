def p():
    return "10"



