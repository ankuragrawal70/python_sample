#include <stdio.h>

void hello()
{
    puts("hello world!");
}
